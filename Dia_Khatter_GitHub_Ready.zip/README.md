# Dia Khatter — Portfolio

A single-file, hash-routed portfolio for GitHub Pages. The homepage has animated rain and an interactive umbrella; each project opens its own addressable view without navigating to a different HTML file.

## Publish on GitHub Pages
1. Create a **public** GitHub repository (for example `dia-portfolio`).
2. Upload `index.html`, `.nojekyll` and this `README.md` to the root of the `main` branch.
3. Go to **Settings → Pages → Build and deployment**, choose **Deploy from a branch**, `main`, `/ (root)`, and save.
4. After deployment, copy the live URL and repository URL into your assignment submission.
5. Check the live site in a private window and on your phone.

## Deep links
- `#project-bereal` — Best Friend Streaks
- `#project-translator` — Resume-to-Role Translator
- `#project-zepto` — Zepto persona and journey map
- `#umbrella-story` — About (story, experience, education, skills)

## Important review before submitting
The three case studies contain real project *deliverables*, but do **not** assert that proposed experiments were launched or achieved results. Review the project evidence and add any verifiable observed outcomes and original visuals you have. External Google Fonts require internet access. Ensure all links work on GitHub Pages. Do not upload a résumé, phone number, home address, birth date, credentials or confidential work.

This is original standalone HTML, CSS and JS; no third-party website template is included.
